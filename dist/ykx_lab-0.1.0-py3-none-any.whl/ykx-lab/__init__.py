# my-pypi-package/my-pypi-package/my_pypi_package/__init__.py

"""
This is the ykx-lab package.

This package provides functionality for ...
"""

from .module import my_function