# ykx-lab/system_monitor/__init__.py

"""
This is the system_monitor package.

This package provides functionality for ...
"""

from .module import my_function