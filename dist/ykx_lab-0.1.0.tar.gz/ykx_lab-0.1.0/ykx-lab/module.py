#class MyClass:
#    def method_one(self):
#        return "Method One"
#
#    def method_two(self):
#        return "Method Two"

def my_function():
    return "Hello from my_function!"